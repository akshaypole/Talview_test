//Requiring mongoose package
var mongoose=require("mongoose");

// Schema
var formSchema=new mongoose.Schema({
	username : String,
	email : String
	age:Number;
	role:String;
	recommed-1:String;
	recommed-2:String;
	recommed-3:String;
	inp:String;
	comment:String;
});

module.exports=mongoose.model("Form",formSchema);
